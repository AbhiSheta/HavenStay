<?php

include 'components/connect.php';

try {
    // Add verification_status column to existing property table
    $conn->exec("ALTER TABLE `property` 
                ADD COLUMN IF NOT EXISTS `verification_status` 
                enum('pending','verified','rejected') DEFAULT 'pending'");

    // Create property_verification table
    $conn->exec("CREATE TABLE IF NOT EXISTS `property_verification` (
        `id` varchar(20) NOT NULL,
        `property_id` varchar(20) NOT NULL,
        `ownership_proof` varchar(50) NOT NULL,
        `tax_receipt` varchar(50) DEFAULT NULL,
        `building_permit` varchar(50) DEFAULT NULL,
        `verification_status` enum('pending','verified','rejected') DEFAULT 'pending',
        `verification_date` timestamp NULL DEFAULT NULL,
        `verified_by` varchar(20) DEFAULT NULL,
        `rejection_reason` text DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `property_id` (`property_id`),
        CONSTRAINT `property_verification_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `property` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Create verification documents directory if it doesn't exist
    if (!file_exists('uploaded_files/verification')) {
        mkdir('uploaded_files/verification', 0777, true);
    }

    echo "Verification system setup completed successfully!";
} catch(PDOException $e) {
    echo "Error setting up verification system: " . $e->getMessage();
}

?> 