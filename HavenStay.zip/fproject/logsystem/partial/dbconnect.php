<?php
$servername="localhost";
$username="root";
$password="";
$database="project";
$conn=mysqli_connect($servername,$username,$password,$database);
// if(!$conn)
// {
//   echo "The connection was not successfull" . mysqli_connect_error();
// }
// else{
//     echo "The Connection was Successfull";
// }
https://source.unsplash.com/random/1080x400/?hotels,rooms
?>