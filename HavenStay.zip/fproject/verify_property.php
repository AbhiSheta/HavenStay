<?php
include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
   header('location:login.php');
}

if(isset($_POST['submit_verification'])){
   $property_id = $_POST['property_id'];
   $property_id = filter_var($property_id, FILTER_SANITIZE_STRING);
   $verification_id = create_unique_id();

   // Handle ownership proof document
   $ownership_proof = $_FILES['ownership_proof']['name'];
   $ownership_proof = filter_var($ownership_proof, FILTER_SANITIZE_STRING);
   $ownership_proof_ext = pathinfo($ownership_proof, PATHINFO_EXTENSION);
   $rename_ownership_proof = create_unique_id().'.'.$ownership_proof_ext;
   $ownership_proof_tmp_name = $_FILES['ownership_proof']['tmp_name'];
   $ownership_proof_folder = 'uploaded_files/verification/'.$rename_ownership_proof;

   // Handle tax receipt document
   $tax_receipt = $_FILES['tax_receipt']['name'];
   $tax_receipt = filter_var($tax_receipt, FILTER_SANITIZE_STRING);
   $tax_receipt_ext = pathinfo($tax_receipt, PATHINFO_EXTENSION);
   $rename_tax_receipt = create_unique_id().'.'.$tax_receipt_ext;
   $tax_receipt_tmp_name = $_FILES['tax_receipt']['tmp_name'];
   $tax_receipt_folder = 'uploaded_files/verification/'.$rename_tax_receipt;

   // Handle building permit document
   $building_permit = $_FILES['building_permit']['name'];
   $building_permit = filter_var($building_permit, FILTER_SANITIZE_STRING);
   $building_permit_ext = pathinfo($building_permit, PATHINFO_EXTENSION);
   $rename_building_permit = create_unique_id().'.'.$building_permit_ext;
   $building_permit_tmp_name = $_FILES['building_permit']['tmp_name'];
   $building_permit_folder = 'uploaded_files/verification/'.$rename_building_permit;

   // Check if verification already exists
   $verify_submission = $conn->prepare("SELECT * FROM `property_verification` WHERE property_id = ?");
   $verify_submission->execute([$property_id]);

   if($verify_submission->rowCount() > 0){
      $warning_msg[] = 'verification already submitted!';
   }else{
      // Insert verification details
      $submit_verification = $conn->prepare("INSERT INTO `property_verification`(id, property_id, ownership_proof, tax_receipt, building_permit) VALUES(?,?,?,?,?)");
      $submit_verification->execute([$verification_id, $property_id, $rename_ownership_proof, $rename_tax_receipt, $rename_building_permit]);

      // Move uploaded files
      if($submit_verification){
         move_uploaded_file($ownership_proof_tmp_name, $ownership_proof_folder);
         move_uploaded_file($tax_receipt_tmp_name, $tax_receipt_folder);
         move_uploaded_file($building_permit_tmp_name, $building_permit_folder);
         $success_msg[] = 'verification documents submitted successfully!';
      }
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Property Verification</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="css/style.css">
</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="property-verification">
   <form action="" method="POST" enctype="multipart/form-data">
      <h3>Property Verification Documents</h3>
      
      <input type="hidden" name="property_id" value="<?= $_GET['property'] ?? ''; ?>">
      
      <div class="box">
         <p>Ownership Proof <span>*</span></p>
         <input type="file" name="ownership_proof" required accept=".pdf,.jpg,.jpeg,.png" class="input">
      </div>
      
      <div class="box">
         <p>Tax Receipt</p>
         <input type="file" name="tax_receipt" accept=".pdf,.jpg,.jpeg,.png" class="input">
      </div>
      
      <div class="box">
         <p>Building Permit</p>
         <input type="file" name="building_permit" accept=".pdf,.jpg,.jpeg,.png" class="input">
      </div>

      <input type="submit" value="Submit for Verification" name="submit_verification" class="btn">
   </form>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<?php include 'components/footer.php'; ?>
<script src="js/script.js"></script>
<?php include 'components/message.php'; ?>

</body>
</html> 