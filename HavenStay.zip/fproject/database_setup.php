<?php

include 'components/connect.php';

try {
    // Create property table
    $conn->exec("CREATE TABLE IF NOT EXISTS `property` (
        `id` varchar(20) NOT NULL,
        `user_id` varchar(20) NOT NULL,
        `property_name` varchar(50) NOT NULL,
        `address` varchar(100) NOT NULL,
        `price` varchar(10) NOT NULL,
        `type` varchar(10) NOT NULL,
        `offer` varchar(10) NOT NULL,
        `status` varchar(50) NOT NULL,
        `furnished` varchar(50) NOT NULL,
        `bhk` varchar(10) NOT NULL,
        `deposite` varchar(10) NOT NULL,
        `bedroom` varchar(10) NOT NULL,
        `bathroom` varchar(10) NOT NULL,
        `balcony` varchar(10) NOT NULL,
        `carpet` varchar(10) NOT NULL,
        `age` varchar(2) NOT NULL,
        `total_floors` varchar(2) NOT NULL,
        `room_floor` varchar(2) NOT NULL,
        `loan` varchar(50) NOT NULL,
        `lift` varchar(3) NOT NULL DEFAULT 'no',
        `security_guard` varchar(3) NOT NULL DEFAULT 'no',
        `play_ground` varchar(3) NOT NULL DEFAULT 'no',
        `garden` varchar(3) NOT NULL DEFAULT 'no',
        `water_supply` varchar(3) NOT NULL DEFAULT 'no',
        `power_backup` varchar(3) NOT NULL DEFAULT 'no',
        `parking_area` varchar(3) NOT NULL DEFAULT 'no',
        `gym` varchar(3) NOT NULL DEFAULT 'no',
        `shopping_mall` varchar(3) NOT NULL DEFAULT 'no',
        `hospital` varchar(3) NOT NULL DEFAULT 'no',
        `school` varchar(3) NOT NULL DEFAULT 'no',
        `market_area` varchar(3) NOT NULL DEFAULT 'no',
        `image_01` varchar(50) NOT NULL,
        `image_02` varchar(50) NOT NULL,
        `image_03` varchar(50) NOT NULL,
        `image_04` varchar(50) NOT NULL,
        `image_05` varchar(50) NOT NULL,
        `description` varchar(1000) NOT NULL,
        `verification_status` enum('pending','verified','rejected') DEFAULT 'pending',
        `date` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Create property_verification table
    $conn->exec("CREATE TABLE IF NOT EXISTS `property_verification` (
        `id` varchar(20) NOT NULL,
        `property_id` varchar(20) NOT NULL,
        `ownership_proof` varchar(50) NOT NULL,
        `tax_receipt` varchar(50) DEFAULT NULL,
        `building_permit` varchar(50) DEFAULT NULL,
        `verification_status` enum('pending','verified','rejected') DEFAULT 'pending',
        `verification_date` timestamp NULL DEFAULT NULL,
        `verified_by` varchar(20) DEFAULT NULL,
        `rejection_reason` text DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `property_id` (`property_id`),
        CONSTRAINT `property_verification_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `property` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Create verification documents directory if it doesn't exist
    if (!file_exists('uploaded_files/verification')) {
        mkdir('uploaded_files/verification', 0777, true);
    }

    echo "Database tables created successfully!";
} catch(PDOException $e) {
    echo "Error creating tables: " . $e->getMessage();
}

?> 