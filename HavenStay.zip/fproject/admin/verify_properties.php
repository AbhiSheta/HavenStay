<?php

include '../components/connect.php';

if(isset($_COOKIE['admin_id'])){
   $admin_id = $_COOKIE['admin_id'];
}else{
   $admin_id = '';
   header('location:login.php');
}

if(isset($_POST['verify_property'])){
   $property_id = $_POST['property_id'];
   $property_id = filter_var($property_id, FILTER_SANITIZE_STRING);
   $verification_id = $_POST['verification_id'];
   $verification_id = filter_var($verification_id, FILTER_SANITIZE_STRING);

   $verify_property = $conn->prepare("UPDATE `property` SET verification_status = 'verified' WHERE id = ?");
   $verify_property->execute([$property_id]);

   $update_verification = $conn->prepare("UPDATE `property_verification` SET verification_status = 'verified', verification_date = NOW(), verified_by = ? WHERE id = ?");
   $update_verification->execute([$admin_id, $verification_id]);

   $success_msg[] = 'property verified successfully!';
}

if(isset($_POST['reject_property'])){
   $property_id = $_POST['property_id'];
   $property_id = filter_var($property_id, FILTER_SANITIZE_STRING);
   $verification_id = $_POST['verification_id'];
   $verification_id = filter_var($verification_id, FILTER_SANITIZE_STRING);
   $rejection_reason = $_POST['rejection_reason'];
   $rejection_reason = filter_var($rejection_reason, FILTER_SANITIZE_STRING);

   $reject_property = $conn->prepare("UPDATE `property` SET verification_status = 'rejected' WHERE id = ?");
   $reject_property->execute([$property_id]);

   $update_verification = $conn->prepare("UPDATE `property_verification` SET verification_status = 'rejected', verification_date = NOW(), verified_by = ?, rejection_reason = ? WHERE id = ?");
   $update_verification->execute([$admin_id, $rejection_reason, $verification_id]);

   $success_msg[] = 'property rejected successfully!';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Property Verifications</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
   
<?php include '../components/admin_header.php'; ?>

<section class="listings">

   <h1 class="heading">Property Verifications</h1>

   <div class="box-container">

   <?php
      $select_properties = $conn->prepare("SELECT pv.*, p.property_name, p.address, u.name as owner_name 
         FROM `property_verification` pv 
         JOIN `property` p ON pv.property_id = p.id 
         JOIN `users` u ON p.user_id = u.id 
         WHERE pv.verification_status = 'pending' 
         ORDER BY pv.created_at DESC");
      $select_properties->execute();
      if($select_properties->rowCount() > 0){
         while($fetch_property = $select_properties->fetch(PDO::FETCH_ASSOC)){
   ?>
   <div class="box">
      <div class="thumb">
         <p class="total-images"><i class="far fa-file"></i><span>3</span></p>
         <p class="type"><span><?= $fetch_property['verification_status']; ?></span></p>
      </div>
      <div class="admin">
         <h3><?= substr($fetch_property['property_name'], 0, 20); ?></h3>
         <div>
            <p><?= $fetch_property['owner_name']; ?></p>
            <span><?= $fetch_property['address']; ?></span>
         </div>
      </div>
      <div class="flex-btn">
         <a href="../uploaded_files/verification/<?= $fetch_property['ownership_proof']; ?>" class="btn" target="_blank">Ownership Proof</a>
         <?php if(!empty($fetch_property['tax_receipt'])){ ?>
            <a href="../uploaded_files/verification/<?= $fetch_property['tax_receipt']; ?>" class="btn" target="_blank">Tax Receipt</a>
         <?php } ?>
         <?php if(!empty($fetch_property['building_permit'])){ ?>
            <a href="../uploaded_files/verification/<?= $fetch_property['building_permit']; ?>" class="btn" target="_blank">Building Permit</a>
         <?php } ?>
      </div>
      <form action="" method="POST">
         <input type="hidden" name="property_id" value="<?= $fetch_property['property_id']; ?>">
         <input type="hidden" name="verification_id" value="<?= $fetch_property['id']; ?>">
         <input type="submit" value="verify property" name="verify_property" class="btn" onclick="return confirm('verify this property?');">
         <button type="button" class="btn" onclick="showRejectForm('<?= $fetch_property['id']; ?>')">reject property</button>
      </form>
      <div id="reject-form-<?= $fetch_property['id']; ?>" style="display: none;">
         <form action="" method="POST">
            <input type="hidden" name="property_id" value="<?= $fetch_property['property_id']; ?>">
            <input type="hidden" name="verification_id" value="<?= $fetch_property['id']; ?>">
            <textarea name="rejection_reason" required placeholder="Enter reason for rejection" class="input"></textarea>
            <input type="submit" value="confirm rejection" name="reject_property" class="btn" onclick="return confirm('reject this property?');">
         </form>
      </div>
   </div>
   <?php
      }
   }else{
      echo '<p class="empty">no properties pending verification!</p>';
   }
   ?>

   </div>

</section>

<script>
function showRejectForm(id) {
   document.getElementById('reject-form-'+id).style.display = 'block';
}
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<?php include '../components/message.php'; ?>

</body>
</html> 